import React, {useState,useEffect} from 'react'

const Covid = () => {
    const [data, setData] = useState([]);
    const getCovidData = async () => {
    const res = await fetch('https://data.covid19india.org/v4/min/timeseries.min.json');
    const actualData= await res.json();
    console.log(actualData.statewise);
    setData(actualData.statewise);
}
    useEffect(() => {
        getCovidData();
      }, []);
    return(
        <>
        
        <div className="container-fluid mt-5">
        <header>
    <nav>
            <ul>
              
            <a className="fnvi" href="http://localhost:3000/bc">National Summary</a>
                
                
                <a className="nvi" href="http://localhost:3000/scc">Statewise Covid Cases</a>
                <a className="nvi" href="http://localhost:3000/f">global</a>
            </ul>
        </nav>
        </header>

            <div className="main-heading">
            <h1 style={{textAlign: 'center'}}>  India COVID-19 Dashboard</h1>
            </div>
            
            <div className="table-responsive">
                <table className="table table-hover">
                    <thead className="thead-dark">
                    <tr>
                        <th style={{
   border: 'solid 2px black',
   
   background: 'white',
   color: 'black',
   fontWeight: 'bold',
   fontSize: '29px' 
 }}> State </th>
                        <th style={{
   
   border: 'solid 2px black',

   background: 'white',
   color: 'rgb(230,90,5)',
   fontWeight: 'bold',
   fontSize: '28px',
   padding: '20px'
 }}> Confirmed </th>
                        <th style={{
   border: 'solid 2px black',
   
   color: 'rgb(0,155,0)',
   background: 'white',
   fontWeight: 'bold',
   fontSize: '28px',
   padding: '20px'
 }}> Recovered </th>
                        <th style={{
   border: 'solid 2px black',
   
   background: 'white',
   color: 'red',
   fontWeight: 'bold',
   fontSize: '28px',
   padding: '20px'
 }}> Death </th>
                        <th style={{
  border: 'solid 2px black',
   
   background: 'whie',
   color: 'rgb(150,29,90)',

   fontWeight: 'bold',
   fontSize: '28px',
   padding: '20px'
 }}> Active </th>
                        <th style={{
   border: 'solid 2px black',
   
   background: 'white',
   color: 'blue',
   fontWeight: 'bold',
   fontSize: '28px',
   padding: '20px'
 }}> Updated </th>
                        
                    </tr>
                    </thead>
                    <tbody>
                        {
                            data.map((curElem, ind) =>{
                                return (
                                    <tr key={ind}>
                        <th style={{
   
   border: 'solid 2px black',
   background: 'rgb(120,0,150)',
   color: 'white',
   fontWeight: 'bold',
   fontSize: '25px'
 }}
 
 > {curElem.state} </th>
                        <td style={{
   border: 'solid 2px black',
   color: 'white',
   background: 'rgb(230,90,5)',
   fontWeight: 'bold',
   fontSize: '26px',
   textAlign: 'center'
 }}> {curElem.confirmed} </td>
                        <td style={{
   border: 'solid 2px black',
   background: 'rgb(0,155,0)',
   color: 'white',
   fontWeight: 'bold',
   fontSize: '26px',
   padding: '17px',
   textAlign: 'center'
 }}> {curElem.recovered} </td>
                        <td style={{
   border: 'solid 2px black',
   background: 'red',
   color: 'white',
   fontWeight: 'bold',
   fontSize: '26px',
   padding: '17px',
   textAlign: 'center'
 }}> {curElem.deaths} </td>
                        <td style={{
   border: 'solid 2px black',
   color: 'black',
   background: 'rgb(240,240,0)',
   
   fontWeight: 'bold',
   fontSize: '26px',
   textAlign: 'center'
 }}> {curElem.active} </td>
                        <td style={{
   border: 'solid 2px black',
   background: 'blue',
   color: 'white',
   fontWeight: 'bold',
   fontSize: '22px',
   padding: '17px',
   textAlign: 'center'
 }}> {curElem.lastupdatedtime} </td>
                        
                    </tr>
                                )
                            })
                        }
                    
                    
                    </tbody>
                </table>

            </div>
        </div>
        </>
    )
}
export default Covid