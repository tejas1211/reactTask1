const QuestionsList = [
   
    {
        question: "What is the full form of WWW ? ",
        answersList: [
            {answer : "World width web", isCorrect: false},
            {answer : "World war web", isCorrect: false},
            {answer : "World wide web", isCorrect: true},
            {answer : "World web wide", isCorrect: false}
        ],
    },
    {
        question: "India's capital? ",
        answersList: [
            {answer : "Mumbai", isCorrect: false},
            {answer : "New Delhi", isCorrect: true},
            {answer : "Chennai", isCorrect: false},
            {answer : "Pune", isCorrect: false}
        ],
    },
    {
        question: "Highest peak? ",
        answersList: [
            {answer : "MT. Everest", isCorrect: true},
            {answer : "Mount K2", isCorrect: false},
            {answer : "Annapurna", isCorrect: false},
            {answer : "Makalu", isCorrect: false}
        ],
    },
    {
        question: "Highest run getter in IPL? ",
        answersList: [
            {answer : "Mr bean", isCorrect: false},
            {answer : "David", isCorrect: false},
            {answer : "Dude", isCorrect: false},
            {answer : "Ryan", isCorrect: true}
        ],
    },
    {
        question: "Who maintains react? ",
        answersList: [
            {answer : "Google", isCorrect: false},
            {answer : "Amazon", isCorrect: false},
            {answer : "FB", isCorrect: true},
            {answer : "Apple", isCorrect: false}
        ],
    },
];
export default QuestionsList;