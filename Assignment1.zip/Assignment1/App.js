import React, {useState} from "react";
import QuestionsList from "./components/QuestionsList";
import {v4 as uuidv4} from "uuid";
import "./App.css";
const App = () => {
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [score, setScore]= useState(-1);
    const [randomIndex, setnm]= useState(0);
    const [clicked, setClicked] = useState(false);
    const [showScore, setShowScore]=useState(false);
    const [name, setName] = useState(true);
    const [modal, setModal] = useState(false);
    const [fe, judgeScore] = useState(false);
    const [se, judgescore] = useState(false);
    const [te, JudgeScore] = useState(false);
    const toggleModal = () => {
        setModal(!modal)
        
      };
    const handlerCorrectAnswer= (isCorrect) => {
        if(isCorrect){
            setScore(score+1);
        }
        setClicked(true);
    }
    const handleNextQuestion =() =>{
        setClicked(false);
        if(currentQuestion<QuestionsList.length -1){
            setCurrentQuestion(currentQuestion+1)
             
        }
        else{
            setShowScore(true);
            if(score===5){
                judgeScore(true);
            }
            else if(score>=3 && score<5){
                judgescore(true);
            }
            else{
                JudgeScore(true);
            }
        }
    }
    return( 
    <div className="app-wrapper">
        {showScore ?(
            
                 
                <div>
                    
      {modal && fe && (
          
        <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="fmodal-content">
          <h2>Well done !!!</h2>
            <h4 className="offer">
              Click on the link for getting the best offer from UpCloud digital healthcare
            </h4>
            <p><a href="#">link</a></p>
          </div>
        </div>
      )}
      {modal && se && (
          
          <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="smodal-content">
            <h2>Very good !!!</h2>
            <h4 className="offer">
              Click on the link for getting the best offer from UpCloud digital healthcare
            </h4>
            <p><a href="#">link</a></p>
            </div>
          
        </div>
        )}
        {modal && te && (
          
          <div className="modal">
            <div onClick={toggleModal} className="overlay"></div>
            <div className="tmodal-content">
            
            <h4 className="offer">
              Sorry, you are not eligible to get the best offer, please try again !!!
            </h4>
            
            </div>
          </div>
        )}
      
                <div className="completed"> completed </div>
                <div className="score-section">
                    Your score : {score}/{QuestionsList.length}
                    
                </div>
                <button onClick={toggleModal} className="btn-modal">
        Check your eligibility
      </button>
                
            </div>
            
            
        ) : (
             
        <div>
            
           
                <div>
            <div className="question-section-wrapper">
                <div className="question-count">
                    Question {currentQuestion+1} of {QuestionsList.length}
                </div>
                <div className="question">

                    {QuestionsList[currentQuestion].question}
                </div>
            </div>
            
            <div className="answer-section-wrapper">
                {QuestionsList[currentQuestion].answersList.map((answerOption)=>(
                    <li className="answer-list" key={uuidv4()}>
                        <button 
                        disabled={clicked}
                        className={`answer-button ${clicked && (!(answerOption.isCorrect) ? "wrong" : "correct")}`}
                        
                        onClick={() => handlerCorrectAnswer(answerOption.isCorrect)}>
                            {answerOption.answer}</button>
                    </li>
                ))}
            </div>
        
        <div>
            <button className="next-button" onClick={handleNextQuestion} disabled={!clicked}>
                Next
            </button>
        </div>
        </div>
           
        </div>
            
    
        )}
        </div>
    );
};

export default App;